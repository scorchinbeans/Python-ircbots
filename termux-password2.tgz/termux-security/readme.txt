To install on termux, just run install
and it will install itself onto your
system.

Requirements:
* PyPi hashlib
